package com.rules.object;

public interface IDress {
	public final static short HAT = 1;
	public final static short PANTS = 2;
	public final static short SHIRT = 3;
	public final static short SHOES = 4;
	public final static short SOCKS = 5;
	public final static short LEAVE = 6;
	
	public String myName();
	public void setRules();
}
