package com.rules;

public class DressFactory {
	static public IRules instance = null;

	private DressFactory() {
		super();
	}

	static public IRules getInstance(int id) {
		switch (id) {
		case IRules.HAT:
			return new Hats(id);
		case IRules.PANTS:
			return new PantsRules(id);
		case IRules.SHIRT:
			return new ShirtRules(id);
		case IRules.SHOES:
			return new ShoesRules(id);
		case IRules.SOCKS:
			return new SocksRules(id);
		case IRules.LEAVE:
			return new LeaveRules(id);
		default:
			return new NoRules(id);
		}
	}
}
