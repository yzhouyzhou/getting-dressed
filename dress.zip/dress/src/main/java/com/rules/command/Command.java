package com.rules.command;

public interface Command {
	public abstract void execute();
}
