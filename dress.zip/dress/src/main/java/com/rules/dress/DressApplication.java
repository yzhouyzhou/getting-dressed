package com.rules.dress;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.rules.DressFactory;
import com.rules.DressStateHandler;

@SpringBootApplication
public class DressApplication {

	public static void main(String[] args) {
		SpringApplication.run(DressApplication.class, args);
		System.out.println("hello world");

		///////////////////////////////////////////////////
		play(new int[] { 5, 2, 3, 4, 6 });
		play(new int[] { 2, 5, 3, 4, 1, 6 });
		play(new int[] { 3, 1, 2, 5, 4, 6 });
		play(new int[] { 4, 3, 2, 1, 6 });
		play(new int[] { 2, 5, 3, 4, 1 });
		play(new int[] { 2, 3, 4, 5, 1 });
		play(new int[] { 5, 1, 3 });
	}

	private static void play(int[] arr) {
		ArrayList<Integer> alist = (ArrayList<Integer>) Arrays.stream(arr).boxed().collect(Collectors.toList());
		DressStateHandler.getInstance().reset();
		alist.stream().forEach(item -> {
			DressFactory.getInstance(item);
		});
		DressStateHandler.getInstance().getStatus();
	}
}
